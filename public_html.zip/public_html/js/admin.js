function  funds(){
	document.getElementById('3div').style.display = "none";
}